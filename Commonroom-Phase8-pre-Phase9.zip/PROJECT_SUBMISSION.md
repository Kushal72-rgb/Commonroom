# Commonroom — project submission document

> **Before submitting:** replace every `[TEAM TO COMPLETE]` field with accurate details. Keep all examples fictional unless your team has permission to use real data.

## Project summary

**Commonroom** is a campus resource-sharing prototype for a makerspace community. It helps students request underused tools and spaces while giving owners a clear approval, handover, condition-record and incident workflow.

**Product link:** [TEAM TO COMPLETE — deploy and paste judge-accessible link]

**Source repository:** [TEAM TO COMPLETE — paste repository link and enable judge access]

**Organizer submission form:** [Open submission form](https://forms.gle/QTD1ZRuPX37Yef37A)

**Team / participant details:** [TEAM TO COMPLETE]

**Team roles and contributions:** [TEAM TO COMPLETE — name each member and their actual contribution]

## Selected use case and users

The prototype focuses on one campus makerspace community sharing equipment and rooms. Its initial catalog includes a laser cutter, 3D printer, camera kit, podcast studio, project room and oscilloscope. These are fictional demo listings.

- **Resource users:** students and project teams who need occasional access to tools or space.
- **Resource owners:** makerspace or lab staff who need to decide who can use their property, under what conditions, and when it was returned.

## Why this problem matters

Specialised equipment and rooms can sit idle while students and early-stage teams cannot afford to buy or privately rent them. Ordinary calendars make a slot visible, but do not by themselves establish training, owner approval, handover condition, return condition, incident handling or fair allocation. Commonroom treats these trust and operating steps as part of the booking itself.

## Proposed solution and complete workflow

1. An owner opens **List a resource**, supplies its name, category, location, description and usage rules, then publishes it.
2. A member searches or filters the resource catalog and opens a listing to read its access requirements.
3. The member selects a date, explains the intended use and acknowledges the requirements before sending a request.
4. The owner opens **Owner desk** and reviews the request and eligibility acknowledgement.
5. The owner approves, declines with a reason, or waitlists it. A waitlisted request can later be approved or declined. Each decision is added to the activity history.
6. An approved member opens **My requests**, checks in and records the resource's initial condition.
7. The member can report an issue and still return the resource with a separate final-condition note. Both actions are recorded separately.
8. The owner can inspect the booking notes, incident reports and activity history.

### Judge walkthrough

1. Open the product link and select **Owner desk** to see the resource manager view.
2. Return to **Discover**, select **Request access** on the Laser Cutter, choose a date, enter a project purpose, and submit.
3. Open **Owner desk** and approve the new request.
4. Open **My requests**, check in with a condition note, then return the tool with a final condition note.
5. Reopen **Owner desk** to see the completed booking record and activity history.
6. To demonstrate incident handling, create another booking and use **Report issue** after check-in. To demonstrate fair allocation, create a second request and place it on the waitlist.

## Features developed

- Resource listing with category, location, availability, usage conditions and owner.
- Search, category filters and an availability-today filter.
- Booking requests with date, purpose and eligibility acknowledgement.
- Owner approval, decline and waitlist actions.
- Check-in and return condition notes.
- Delay, damage or other issue reporting.
- Request cancellation while pending.
- Shared activity history for important workflow actions.
- Responsive layout for desktop and mobile browser widths.

## Technology and system architecture

- **Frontend:** vanilla HTML, CSS and JavaScript.
- **State:** browser `localStorage` under the key `commonroom-v1`.
- **External services:** no backend APIs or AI services. Google Fonts may load from its public font host; system font fallbacks are provided.

```text
index.html + styles.css
        │ renders and collects actions
        ▼
app.js — catalog rendering, dialogs, and user actions
        │ delegates lifecycle state changes
        ▼
workflow.js — validated request transitions and audit entries
        │ reads/writes
        ▼
Browser localStorage — resources, requests, incidents, activity history
```

The product is a local, single-browser prototype. The same state powers member and owner views so the lifecycle can be demonstrated without separate accounts or manual data setup.

## Privacy, security, trust and fairness

- Demo people, resources and activity are fictional; the prototype does not request identity documents or confidential institutional records.
- Usage requirements and eligibility acknowledgement are visible to both member and owner. Owners make approval and safety decisions; no automated model decides access or penalties.
- The owner can decline or waitlist a request. The prototype records the action and reason in its activity history.
- The demo's local browser storage is not a secure multi-user store. Do not use it for real personal, institutional or safety-sensitive information.
- Before real deployment, add authentication, server-side role checks, institution-approved verification, access-controlled storage, retention controls, and protected audit logging.
- Fair allocation is demonstrated through owner-controlled waitlisting, later owner processing, and visible decision history. This version does not automatically enforce quotas or calculate queue priority.

## Testing instructions and judge access

- **Product URL:** [TEAM TO COMPLETE — ensure it is publicly or judge accessible]
- **Credentials:** None for the local prototype.
- **Local fallback:** open `index.html` in a modern browser. State is saved in that browser. To reset the demo, remove the `commonroom-v1` local-storage entry for the page origin.
- **Workflow checks:** from the project folder, run `node --test tests/workflow.test.js`.
- **Recommended demonstration:** follow the Judge walkthrough above.

## Known limitations

- Single-user, single-browser persistence; no real account roles or cross-device sync.
- Demo membership and owner labels do not verify an institution or person.
- No calendar integration, concurrent booking lock, email/SMS notification, photo upload, deposit/payment, formal dispute process or tamper-resistant audit storage.
- Waitlist placement is a manual owner decision; automated usage limits and priority rules are not implemented.
- Availability labels are demo data, not live inventory or a conflict-checked calendar.

## Future development

Add institution SSO and server-enforced roles; integrate training records and calendar availability; add fair-use quotas and explainable waitlist rules; support condition photos with consent and retention controls; provide reminders and owner notifications; and store append-only audit events with role-based access and incident-resolution status.

## Tools, templates and pre-existing materials disclosure

- Frameworks and libraries: no third-party JavaScript libraries; browser APIs only.
- Templates or starter code: [TEAM TO COMPLETE — disclose any used, or state none if accurate].
- AI tools: [TEAM TO COMPLETE — accurately disclose tools and how they were used].
- Development window: [TEAM TO COMPLETE — state when the submitted product was built and provide any requested evidence].
