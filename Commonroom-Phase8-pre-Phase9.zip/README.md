# Commonroom

Commonroom is a campus resource sharing app. The browser frontend uses the Express API in `backend/` for authentication, resources, bookings, incidents, and activity history.

## Run locally

1. Start MongoDB Community Server.
2. In a terminal, open `backend/`. Ensure the ignored `.env` file has `MONGODB_URI=mongodb://127.0.0.1:27017/commonroom`, a `JWT_SECRET` of at least 32 bytes, and a suitable `CORS_ORIGIN` (default local frontend origins are configured in `server.js`).
3. Run `npm install` once, then `npm start` from `backend/`. The API listens on port 5000 by default; `GET http://127.0.0.1:5000/api/health` should return `status: "ok"`.
4. In another terminal at the project root, run `python -m http.server 5500`.
5. Open `http://127.0.0.1:5500`.

To use a different API address, define `window.COMMONROOM_API_BASE` in `index.html` before loading `api.js`. Configure the backend CORS allowlist for the frontend origin.

## Frontend structure

- `index.html` and `styles.css` provide the existing interface and responsive layout.
- `app.js` renders screens and drives user interactions.
- `api.js` centralizes API URL, authorization, JSON handling, and errors.
- `workflow.js` retains the DOM-free escaping and validation helpers used by frontend tests.

The frontend stores only the JWT and safe profile cache in localStorage (`commonroom.auth.token` and `commonroom.auth.profile`) so the session can be restored on refresh. Passwords and application data are never stored there. A JavaScript-readable token can be stolen by injected script, so production should prefer secure HttpOnly cookies and a suitable CSRF strategy.

Public registration creates members only. To test owner actions, use `backend/scripts/provision-demo-owner.js` locally; there is no public role promotion endpoint. Eligibility is checked against server-side verified eligibility, so a user cannot grant themselves eligibility from the browser.

Run frontend checks from the project root with `node --test tests/workflow.test.js tests/api.test.js`. Run backend integration tests from `backend/` with `npm test`; MongoDB must be running and `.env` configured.
