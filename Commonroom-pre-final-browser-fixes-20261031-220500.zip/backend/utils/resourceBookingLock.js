const { randomUUID } = require('node:crypto');
const Resource = require('../models/Resource');

async function acquireResourceBookingLock(resourceId, { requireActive = true } = {}) {
  const token = randomUUID();
  const filter = { _id: resourceId, approvalLockToken: null };
  if (requireActive) filter.status = 'active';

  const resource = await Resource.findOneAndUpdate(
    filter,
    { $set: { approvalLockToken: token } },
    { returnDocument: 'after' }
  );
  if (resource) return { token, resource };

  const current = await Resource.findById(resourceId).select('_id status');
  if (!current) return { error: { status: 404, message: 'Resource not found.' } };
  if (requireActive && current.status !== 'active') {
    return { error: { status: 409, message: 'Resource is not active.' } };
  }
  return { error: { status: 409, message: 'Another booking operation for this resource is in progress; retry shortly.' } };
}

async function releaseResourceBookingLock(resourceId, token) {
  if (!resourceId || !token) return;
  try {
    await Resource.updateOne(
      { _id: resourceId, approvalLockToken: token },
      { $unset: { approvalLockToken: 1 } }
    );
  } catch {
    console.error('Resource booking lock could not be released; local recovery may be required.');
  }
}

module.exports = { acquireResourceBookingLock, releaseResourceBookingLock };
